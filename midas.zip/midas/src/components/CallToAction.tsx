
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface CallToActionProps {
  headline: string;
  description?: string;
  buttonText: string;
  buttonLink: string;
  className?: string;
  bgColor?: 'primary' | 'secondary' | 'light';
}

const CallToAction: React.FC<CallToActionProps> = ({
  headline,
  description,
  buttonText,
  buttonLink,
  className = '',
  bgColor = 'primary'
}) => {
  const bgClasses = {
    primary: 'bg-primary text-white',
    secondary: 'bg-secondary text-neutral-dark',
    light: 'bg-neutral-light text-neutral-dark'
  };

  return (
    <section className={`${bgClasses[bgColor]} py-16 ${className}`}>
      <div className="container-custom text-center">
        <h2 className={`text-3xl md:text-4xl font-bold mb-6 ${bgColor === 'primary' ? 'text-white' : 'text-neutral-dark'}`}>
          {headline}
        </h2>
        {description && (
          <p className={`text-lg max-w-2xl mx-auto mb-8 ${bgColor === 'primary' ? 'text-white/90' : 'text-neutral-dark/80'}`}>
            {description}
          </p>
        )}
        <Link to={buttonLink}>
          {bgColor === 'primary' ? (
            <Button className="bg-white text-primary hover:bg-neutral-light text-lg px-8 py-6 h-auto">
              {buttonText}
            </Button>
          ) : (
            <Button className="bg-primary text-white hover:bg-primary-dark text-lg px-8 py-6 h-auto">
              {buttonText}
            </Button>
          )}
        </Link>
      </div>
    </section>
  );
};

export default CallToAction;
