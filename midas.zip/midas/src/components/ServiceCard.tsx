
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

interface ServiceCardProps {
  title: string;
  description: string;
  benefits: string[];
  icon: React.ReactNode;
  link: string;
  idealFor?: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({
  title,
  description,
  benefits,
  icon,
  link,
  idealFor
}) => {
  return (
    <Card className="h-full flex flex-col">
      <CardHeader>
        <div className="mb-4 text-primary">{icon}</div>
        <CardTitle className="text-2xl">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow">
        <CardDescription className="text-base mb-6">{description}</CardDescription>
        <h4 className="font-semibold text-lg mb-3">Key Benefits:</h4>
        <ul className="space-y-2 mb-6">
          {benefits.map((benefit, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-primary shrink-0 mt-0.5 mr-2" />
              <span>{benefit}</span>
            </li>
          ))}
        </ul>
        {idealFor && (
          <div>
            <h4 className="font-semibold text-lg mb-2">Ideal For:</h4>
            <p className="text-neutral-dark/90">{idealFor}</p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Link to={link} className="w-full">
          <Button className="w-full">Learn More</Button>
        </Link>
      </CardFooter>
    </Card>
  );
};

export default ServiceCard;
