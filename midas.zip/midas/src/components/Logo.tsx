
import React from 'react';

const Logo: React.FC = () => {
  return (
    <div className="flex items-center">
      <img 
        src="/lovable-uploads/d871661f-f766-4172-9759-8ffc0006d9a8.png" 
        alt="Midas Consulting Logo" 
        className="h-14 w-auto mr-2" 
      />
    </div>
  );
};

export default Logo;
