
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ProcessStepProps {
  number: number;
  title: string;
  description: string;
}

const ProcessStep: React.FC<ProcessStepProps> = ({
  number,
  title,
  description
}) => {
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold mb-3">
          {number}
        </div>
        <CardTitle className="text-xl font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-neutral-dark/80">{description}</p>
      </CardContent>
    </Card>
  );
};

export default ProcessStep;
