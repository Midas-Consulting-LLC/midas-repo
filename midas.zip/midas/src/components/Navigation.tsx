
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import Logo from './Logo';

const Navigation: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container-custom py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center">
            <Logo />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/services" className="text-neutral-dark font-medium hover:text-primary transition-colors">
              Services
            </Link>
            <Link to="/how-it-works" className="text-neutral-dark font-medium hover:text-primary transition-colors">
              How It Works
            </Link>
            <Link to="/why-us" className="text-neutral-dark font-medium hover:text-primary transition-colors">
              Why Us
            </Link>
            <Link to="/blog" className="text-neutral-dark font-medium hover:text-primary transition-colors">
              Blog
            </Link>
            <Link to="/contact" className="text-neutral-dark font-medium hover:text-primary transition-colors">
              Contact
            </Link>
            <Link to="/book-consultation">
              <Button className="bg-primary text-white hover:bg-primary-dark">Book a Consultation</Button>
            </Link>
          </nav>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="text-neutral-dark hover:text-primary transition-colors"
              aria-expanded={isMenuOpen}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 space-y-4">
            <Link 
              to="/services" 
              className="block text-neutral-dark font-medium hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Services
            </Link>
            <Link 
              to="/how-it-works" 
              className="block text-neutral-dark font-medium hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              How It Works
            </Link>
            <Link 
              to="/why-us" 
              className="block text-neutral-dark font-medium hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Why Us
            </Link>
            <Link 
              to="/blog" 
              className="block text-neutral-dark font-medium hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Blog
            </Link>
            <Link 
              to="/contact" 
              className="block text-neutral-dark font-medium hover:text-primary transition-colors py-2"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
            <Link 
              to="/book-consultation" 
              className="block"
              onClick={() => setIsMenuOpen(false)}
            >
              <Button className="w-full bg-primary text-white hover:bg-primary-dark">Book a Consultation</Button>
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Navigation;
