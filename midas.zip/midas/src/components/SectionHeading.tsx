
import React from 'react';

interface SectionHeadingProps {
  title: string;
  subtitle?: string;
  centered?: boolean;
  alignment?: string; // Adding this optional prop to fix the error
}

const SectionHeading: React.FC<SectionHeadingProps> = ({ 
  title, 
  subtitle,
  centered = false,
  alignment
}) => {
  // If alignment is provided, use it, otherwise use centered prop
  const textAlignment = alignment ? 
    alignment === 'center' ? 'text-center' : 
    alignment === 'right' ? 'text-right' : '' : 
    centered ? 'text-center' : '';

  return (
    <div className={`mb-10 md:mb-16 ${textAlignment}`}>
      <h2 className="text-neutral-dark mb-4">{title}</h2>
      {subtitle && (
        <p className="text-lg text-neutral-dark/80 max-w-3xl">
          {subtitle}
        </p>
      )}
    </div>
  );
};

export default SectionHeading;
