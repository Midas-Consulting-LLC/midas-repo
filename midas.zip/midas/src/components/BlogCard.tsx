
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardFooter, CardHeader } from '@/components/ui/card';

interface BlogCardProps {
  title: string;
  excerpt: string;
  date: string;
  slug: string;
  imageUrl?: string;
}

const BlogCard: React.FC<BlogCardProps> = ({ title, excerpt, date, slug, imageUrl }) => {
  return (
    <Card className="h-full flex flex-col hover:shadow-lg transition-shadow">
      {imageUrl && (
        <div className="aspect-video w-full overflow-hidden">
          <img 
            src={imageUrl} 
            alt={title} 
            className="w-full h-full object-cover transition-transform hover:scale-105"
          />
        </div>
      )}
      <CardHeader className="pb-2">
        <h3 className="text-xl font-semibold text-neutral-dark hover:text-primary transition-colors">
          {title}
        </h3>
        <p className="text-sm text-neutral">{date}</p>
      </CardHeader>
      <CardContent className="flex-grow">
        <p className="text-neutral-dark/80 line-clamp-3">{excerpt}</p>
      </CardContent>
      <CardFooter>
        <Link 
          to={`/blog/${slug}`} 
          className="text-primary font-medium hover:text-primary-dark transition-colors"
        >
          Read More
        </Link>
      </CardFooter>
    </Card>
  );
};

export default BlogCard;
