
import React from 'react';
import { Link } from 'react-router-dom';
import Logo from './Logo';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-neutral-dark text-white">
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
          <div className="col-span-1">
            <Logo />
            <p className="mt-4 text-neutral-light opacity-80">
              We specialize in providing outsourced sales teams, AI-enhanced lead generation, and targeted lead research for businesses looking to scale their revenue.
            </p>
          </div>

          <div className="col-span-1">
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="text-neutral-light opacity-80 hover:opacity-100 transition-opacity">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/how-it-works" className="text-neutral-light opacity-80 hover:opacity-100 transition-opacity">
                  How It Works
                </Link>
              </li>
              <li>
                <Link to="/why-us" className="text-neutral-light opacity-80 hover:opacity-100 transition-opacity">
                  Why Us
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-neutral-light opacity-80 hover:opacity-100 transition-opacity">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-neutral-light opacity-80 hover:opacity-100 transition-opacity">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/book-consultation" className="text-neutral-light opacity-80 hover:opacity-100 transition-opacity">
                  Book a Consultation
                </Link>
              </li>
            </ul>
          </div>

          <div className="col-span-1">
            <h3 className="text-xl font-semibold mb-4">Our Services</h3>
            <ul className="space-y-2">
              <li className="text-neutral-light opacity-80">
                <span className="block">Prospecting</span>
                <span className="block text-xs">AI Tools, Live Scrubbing, Research, Marketing Qualified Leads</span>
              </li>
              <li className="text-neutral-light opacity-80">
                <span className="block">Engagement</span>
                <span className="block text-xs">Email Blasts, Cold Calling, Door Knocking, Mailers, Outsourced Trained Labor</span>
              </li>
              <li className="text-neutral-light opacity-80">
                <span className="block">Discovery</span>
                <span className="block text-xs">Outsourced Trained Labor, High Quality Discovery Recaps, AI Tools</span>
              </li>
            </ul>
          </div>

          <div className="col-span-1">
            <h3 className="text-xl font-semibold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="text-neutral-light opacity-80">
                <span className="block">Email: info@midasconsultingllc.com</span>
              </li>
              <li className="text-neutral-light opacity-80">
                <span className="block">Phone: +1 (678) 782-6664</span>
              </li>
              <li className="text-neutral-light opacity-80">
                <span className="block">Address: 1013 Pasadena Ave. Metairie, LA 70001</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 text-center">
          <p className="text-neutral-light opacity-70">
            &copy; {currentYear} Midas Consulting, LLC. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
