
import { useEffect, useState } from 'react';
import { DatabaseService } from '@/services/DatabaseService';
import { User, Consultation } from '@/types/UserDatabase';
import { useToast } from '@/components/ui/use-toast';

interface CalendlyEventData {
  event: string;
  payload: {
    event: {
      uuid: string;
      start_time: string;
      end_time: string;
      invitee: {
        uuid: string;
        name: string;
        email: string;
        text_reminder_number: string;
      };
    };
  };
}

/**
 * A hook to handle Calendly integration events
 * and sync with our database service
 */
export const useCalendlyIntegration = () => {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastBooking, setLastBooking] = useState<Consultation | null>(null);

  useEffect(() => {
    const handleCalendlyEvent = async (e: MessageEvent) => {
      // Check if this is a Calendly event
      if (e.data.event && e.data.event.indexOf('calendly') === 0) {
        const eventData = e.data as CalendlyEventData;
        
        // Handle scheduled events
        if (eventData.event === 'calendly.event_scheduled') {
          try {
            setIsProcessing(true);
            
            // Extract information from Calendly event
            const { invitee, start_time } = eventData.payload.event;
            const startDate = new Date(start_time);
            
            // Format names by splitting at space
            const nameParts = invitee.name.split(' ');
            const firstName = nameParts[0] || '';
            const lastName = nameParts.slice(1).join(' ') || '';
            
            // Create user in database
            const user = await DatabaseService.createUser({
              firstName,
              lastName,
              email: invitee.email,
              phone: invitee.text_reminder_number,
            });
            
            // Schedule consultation in database
            const consultation = await DatabaseService.scheduleConsultation({
              userId: user.id,
              scheduledDate: startDate,
              scheduledTime: startDate.toLocaleTimeString(),
              status: 'scheduled',
              notes: 'Scheduled via Calendly integration',
            });
            
            // Create lead record
            await DatabaseService.createLead({
              firstName,
              lastName,
              email: invitee.email,
              phone: invitee.text_reminder_number,
              source: 'calendly',
              status: 'new',
            });
            
            setLastBooking(consultation);
            
            toast({
              title: "Consultation Booked",
              description: `${firstName} ${lastName} scheduled for ${startDate.toLocaleDateString()} at ${startDate.toLocaleTimeString()}`,
            });
          } catch (error) {
            console.error('Error processing Calendly event:', error);
            toast({
              title: "Booking Error",
              description: "There was an issue processing your booking. Our team has been notified.",
              variant: "destructive",
            });
          } finally {
            setIsProcessing(false);
          }
        }
      }
    };

    window.addEventListener('message', handleCalendlyEvent);
    return () => window.removeEventListener('message', handleCalendlyEvent);
  }, [toast]);

  return { isProcessing, lastBooking };
};
