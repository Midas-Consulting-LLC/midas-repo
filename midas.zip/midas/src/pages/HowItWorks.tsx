
import React from 'react';
import Layout from '@/components/Layout';
import SectionHeading from '@/components/SectionHeading';
import ProcessStep from '@/components/ProcessStep';
import CallToAction from '@/components/CallToAction';

const HowItWorks: React.FC = () => {
  const processSteps = [
    {
      number: 1,
      title: "Discovery & Strategy",
      description: "Collaborate with your team to identify business objectives, define your ICP (Ideal Customer Profile), and set measurable goals."
    },
    {
      number: 2,
      title: "AI & Data Analysis",
      description: "Our AI scans vast prospect datasets to identify and cluster leads that match your exact ICP criteria."
    },
    {
      number: 3,
      title: "Lead Scrubbing & Verification",
      description: "We cross-check data for accuracy, ensuring every lead is both valid and relevant to your solution offering."
    },
    {
      number: 4,
      title: "In-Depth Research",
      description: "We layer on critical insights—industry trends, organizational structure, buying triggers—to prepare personalized outreach."
    },
    {
      number: 5,
      title: "Qualification & Engagement",
      description: "Either we hand off vetted leads to your internal team or engage prospects on your behalf via our outsourced sales reps."
    },
    {
      number: 6,
      title: "Reporting & Optimization",
      description: "Track conversions, gather feedback, and continuously refine targeting strategies for ongoing improvement."
    }
  ];

  return (
    <Layout>
      {/* Header Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-5xl font-bold text-neutral-dark mb-6">
              Our Proven Process
            </h1>
            <p className="text-lg md:text-xl text-neutral-dark/80">
              Learn how we consistently deliver qualified leads and closed deals by merging technology, data, and real sales experience.
            </p>
          </div>
        </div>
      </section>

      {/* Process Steps */}
      <section className="bg-white">
        <div className="container-custom py-16 md:py-24">
          <SectionHeading
            title="Our 6-Step Sales Growth Methodology"
            subtitle="A transparent, step-by-step approach that blends AI-driven precision with human expertise."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {processSteps.map((step, index) => (
              <ProcessStep
                key={index}
                number={step.number}
                title={step.title}
                description={step.description}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Process Visual Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading
                title="How Our Process Benefits You"
                subtitle="Our methodical approach ensures consistent results while maximizing efficiency."
              />
              
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center font-bold mr-3 mt-0.5">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Reduced Wasted Effort</h4>
                    <p className="text-neutral-dark/80">
                      By focusing only on qualified leads, your team spends time on opportunities that matter.
                    </p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center font-bold mr-3 mt-0.5">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Higher Conversion Rates</h4>
                    <p className="text-neutral-dark/80">
                      Our detailed insights enable more personalized, effective outreach.
                    </p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center font-bold mr-3 mt-0.5">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Scalable & Consistent</h4>
                    <p className="text-neutral-dark/80">
                      Our process adapts to your needs, whether you need 10 or 1,000 leads per month.
                    </p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="h-6 w-6 rounded-full bg-primary text-white flex items-center justify-center font-bold mr-3 mt-0.5">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg">Transparent Reporting</h4>
                    <p className="text-neutral-dark/80">
                      Regular updates and clear metrics help you track ROI and pipeline health.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
            <div className="hidden lg:block">
              <img 
                src="/placeholder.svg" 
                alt="Our Process Visualization" 
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CallToAction
        headline="See How Our Process Can Fuel Your Growth"
        description="Book a consultation to learn how our methodology can be tailored to your specific business needs."
        buttonText="Book a Consultation"
        buttonLink="/book-consultation"
        bgColor="primary"
      />
    </Layout>
  );
};

export default HowItWorks;
