
import React from 'react';
import Layout from '../components/Layout';
import BlogCard from '../components/BlogCard';
import SectionHeading from '../components/SectionHeading';

const Blog: React.FC = () => {
  // This would typically come from an API or CMS
  const blogPosts = [
    {
      id: 1,
      title: "So, You Wanted to Be a Reseller",
      slug: "so-you-wanted-to-be-a-reseller",
      excerpt: "A Love Letter to the Accountants and Developers Who Accidentally Built IT Empires. It always starts innocently enough...",
      date: "April 28, 2025",
      imageUrl: "/lovable-uploads/d871661f-f766-4172-9759-8ffc0006d9a8.png"
    },
    // More blog posts would be added here as they're created
  ];

  return (
    <Layout>
      <div className="container-custom py-16 md:py-24">
        <SectionHeading
          title="The Midas Touch Blog"
          subtitle="Insights, strategies, and stories from the world of outsourced sales"
          alignment="center"
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {blogPosts.map(post => (
            <BlogCard 
              key={post.id}
              title={post.title}
              excerpt={post.excerpt}
              date={post.date}
              slug={post.slug}
              imageUrl={post.imageUrl}
            />
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Blog;
