
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Layout from '../components/Layout';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

const BlogPost: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  
  // In a real app, this would be fetched from an API or CMS based on the slug
  const blogContent = {
    "so-you-wanted-to-be-a-reseller": {
      title: "So, You Wanted to Be a Reseller",
      subtitle: "A Love Letter to the Accountants and Developers Who Accidentally Built IT Empires",
      date: "April 28, 2025",
      author: "Midas Consulting Team",
      content: `
        <p>It always starts innocently enough.</p>
        <p>You fix someone's printer. You untangle a QuickBooks nightmare left behind by a "friend of a friend." Maybe you just wanted to automate a few reports, wrote a simple script, and before you knew it—you were managing 37 client servers and explaining DNS to someone's uncle over Thanksgiving dinner.</p>
        <p>Congratulations, my friend: you've officially become an MSP. Or at least, you've started walking that path. And here's the kicker: you never actually sold anything. You simply told people, with all the fire and passion of a founder, why your solution was amazing.</p>
        <p>You're not alone. The IT channel is filled with accidental entrepreneurs — accountants tired of fixing Excel macros, developers who just wanted to automate patching. People who never set out to build companies, but who couldn't help sharing what they built.</p>
        <p>But here's the tough part: passion doesn't scale easily.</p>
        <p>Sure, you can find your first few clients just by being you — the trusted expert. But when it comes time to grow, to step back, to let someone else sell for you... that's when it gets tricky.</p>
        <p>A company I once consulted with learned this lesson the hard way. It was a family-run business, founded back in '79 in Florida. Grandfather started it, his daughter and grandson took it forward. When they decided to expand into Louisiana, they assumed their grandson could lead the charge.</p>
        <p>One problem: he had never lived outside the safe bubble of the family business. He couldn't imagine needing sales pitches, CRM systems, email campaigns, or customer testimonials. After all, he had never needed them himself.</p>
        <p>The result? They hired three different salespeople over 16 months, burning $50,816 in salaries—with almost nothing to show for it. No market presence. No sales foundation. Just frustration and a lot of wasted time.</p>
        <p>Sound familiar?</p>
        <p>The reality is, there are very few Ivy League classes that teach you how to knock on doors, smile through rejection, or dial-for-dollars until your voice cracks. Universities tell us to focus on "inbound opportunities." And sure, in an ideal world, inbound rocks. But for most of us, bootstrapping businesses and pushing through competitive markets, we can't wait around for leads to magically appear.</p>
        <p>That's why building a real sales system — with people who can find, nurture, and close opportunities — is non-negotiable.</p>
        <p>You need exceptional sales talent. Fast ramp-up times. People who live for crushing KPIs.</p>
        <p>And here's the good news: over the next few months, we're going to explore exactly how to find them, recruit them, onboard them, and keep them.</p>
        <p>But first—ask yourself:</p>
        <p>Are you unknowingly making the same mistakes?</p>
        <p>Have you built an amazing business, but neglected the engine that will truly drive its growth?</p>
        <p>If you even suspect that attracting, onboarding, and keeping top sales talent is an area where you're struggling (or could improve), <a href="/contact" class="text-primary hover:underline">contact us today</a>.</p>
        <p>Let's make sure your passion doesn't just start the fire — it spreads it.</p>
      `
    }
  };
  
  const post = blogContent[slug as keyof typeof blogContent];
  
  if (!post) {
    return (
      <Layout>
        <div className="container-custom py-16 md:py-24 text-center">
          <h1 className="text-3xl font-bold mb-4">Blog Post Not Found</h1>
          <Link to="/blog">
            <Button>Return to Blog</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container-custom py-16 md:py-24">
        <Link to="/blog" className="flex items-center text-primary mb-8 hover:text-primary-dark transition-colors">
          <ArrowLeft size={16} className="mr-2" />
          Back to Blog
        </Link>
        
        <article className="max-w-4xl mx-auto">
          <header className="mb-10">
            <h1 className="text-4xl md:text-5xl font-bold mb-3">{post.title}</h1>
            <h2 className="text-xl md:text-2xl text-neutral-dark/80 mb-4">{post.subtitle}</h2>
            <div className="flex items-center text-sm text-neutral">
              <span>{post.author}</span>
              <span className="mx-2">•</span>
              <time>{post.date}</time>
            </div>
          </header>
          
          <div 
            className="prose prose-lg max-w-none prose-headings:font-semibold prose-p:text-neutral-dark/90"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
        </article>
      </div>
    </Layout>
  );
};

export default BlogPost;
