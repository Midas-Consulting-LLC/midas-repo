
import React, { useEffect } from 'react';
import Layout from '@/components/Layout';
import SectionHeading from '@/components/SectionHeading';
import { Card, CardContent } from '@/components/ui/card';
import { useCalendlyIntegration } from '@/hooks/useCalendlyIntegration';

const BookConsultation: React.FC = () => {
  const { isProcessing } = useCalendlyIntegration();

  useEffect(() => {
    // Load Calendly script
    const head = document.querySelector('head');
    const script = document.createElement('script');
    script.src = 'https://assets.calendly.com/assets/external/widget.js';
    script.async = true;
    head?.appendChild(script);

    // Cleanup on component unmount
    return () => {
      if (head?.contains(script)) {
        head.removeChild(script);
      }
    };
  }, []);

  return (
    <Layout>
      {/* Header Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-neutral-dark mb-6">
              Book Your Free Sales Strategy Consultation
            </h1>
            <p className="text-lg md:text-xl text-neutral-dark/80">
              Select a convenient time to discuss your sales challenges, opportunities, and how our outsourced solutions can accelerate growth.
            </p>
          </div>
        </div>
      </section>

      {/* Calendly Section */}
      <section className="bg-white">
        <div className="container-custom py-16 md:py-24">
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div 
                className="calendly-inline-widget" 
                data-url="https://calendly.com/midasconsultingllc/30min"
                style={{ minWidth: '320px', height: '700px' }}
              ></div>
              {isProcessing && (
                <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                    <p className="text-lg font-medium">Processing your booking...</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="mt-12 max-w-3xl mx-auto">
            <SectionHeading
              title="What to Expect During Your Consultation"
              centered={true}
            />

            <div className="space-y-6">
              <div className="bg-neutral-light p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-2">Understanding Your Needs</h3>
                <p className="text-neutral-dark/80">
                  We'll discuss your current sales challenges, goals, and what specific outcomes you're looking to achieve.
                </p>
              </div>

              <div className="bg-neutral-light p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-2">Solution Overview</h3>
                <p className="text-neutral-dark/80">
                  Based on your needs, we'll outline potential approaches and how our services can be tailored to your business.
                </p>
              </div>

              <div className="bg-neutral-light p-6 rounded-lg">
                <h3 className="text-xl font-semibold mb-2">Next Steps & Timeline</h3>
                <p className="text-neutral-dark/80">
                  We'll discuss implementation options, timelines, and answer any questions you might have.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BookConsultation;
