
import React from 'react';
import Layout from '@/components/Layout';
import SectionHeading from '@/components/SectionHeading';
import CallToAction from '@/components/CallToAction';
import { Card, CardContent } from '@/components/ui/card';
import { Check } from 'lucide-react';

const WhyUs: React.FC = () => {
  const differentiators = [
    {
      title: "Enterprise Sales Leadership",
      description: "Decades of track record with global accounts"
    },
    {
      title: "AI-Powered Efficiency",
      description: "Leverage modern tech to cut through the noise"
    },
    {
      title: "Rigorous Qualification",
      description: "High-intent leads that genuinely match your offering"
    },
    {
      title: "Flexible, Scalable Solutions",
      description: "From targeted lead gen to full outsourced teams"
    },
    {
      title: "Results-Focused",
      description: "Clear, measurable KPIs for accountability"
    }
  ];

  return (
    <Layout>
      {/* Header Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-5xl font-bold text-neutral-dark mb-6">
              Why Partner With Us?
            </h1>
            <p className="text-lg md:text-xl text-neutral-dark/80">
              Our mission is to make enterprise-grade sales expertise accessible to businesses of all sizes. Learn more about our team and what drives us.
            </p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="bg-white">
        <div className="container-custom py-16 md:py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionHeading
                title="Our Story & Expertise"
              />
              
              <div className="space-y-6">
                <p className="text-lg text-neutral-dark/80">
                  Founded by a former NCR executive with 20+ years in enterprise sales, we recognized a market gap where smaller companies struggled to compete in sales due to limited resources. Our goal is to democratize professional, high-level sales strategies.
                </p>
                <p className="text-lg text-neutral-dark/80">
                  We've built an approach that blends AI-driven data analysis with the hands-on, relationship-focused methods honed in Fortune 500 settings. This unique synergy delivers unmatched value to our clients.
                </p>
              </div>
            </div>
            <div className="hidden lg:block">
              <img 
                src="/placeholder.svg" 
                alt="Our Team" 
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <SectionHeading
            title="Our Leadership Team"
            subtitle="Meet the experts driving our client success."
            centered={true}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="overflow-hidden">
              <div className="bg-neutral-200 h-64 flex items-center justify-center">
                <span className="text-neutral-dark/40 text-xl">Founder Photo</span>
              </div>
              <CardContent className="pt-6">
                <h3 className="text-2xl font-semibold mb-2">Founder Name #1</h3>
                <p className="text-neutral-dark/80">
                  A seasoned sales leader with decades of experience in crafting and executing large-scale sales strategies. Passionate about helping businesses optimize revenue through proven methodologies.
                </p>
              </CardContent>
            </Card>

            <Card className="overflow-hidden">
              <div className="bg-neutral-200 h-64 flex items-center justify-center">
                <span className="text-neutral-dark/40 text-xl">Founder Photo</span>
              </div>
              <CardContent className="pt-6">
                <h3 className="text-2xl font-semibold mb-2">Founder Name #2</h3>
                <p className="text-neutral-dark/80">
                  Brings deep operational expertise to the table, ensuring processes, AI tools, and teams align perfectly to deliver impactful results for clients.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Differentiators Section */}
      <section className="bg-white">
        <div className="container-custom py-16 md:py-24">
          <SectionHeading
            title="Our Key Differentiators"
            subtitle="What makes our approach stand out in the industry."
            centered={true}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {differentiators.map((item, index) => (
              <Card key={index} className="p-6">
                <div className="flex">
                  <div className="mr-4">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <Check className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-neutral-dark/80">{item.description}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CallToAction
        headline="Let Our Experience Drive Your Success"
        description="Ready to elevate your sales strategy with enterprise-level expertise?"
        buttonText="Book a Consultation"
        buttonLink="/book-consultation"
        bgColor="primary"
      />
    </Layout>
  );
};

export default WhyUs;
