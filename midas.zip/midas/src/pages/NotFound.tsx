
import React from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';

const NotFound: React.FC = () => {
  return (
    <Layout>
      <div className="min-h-[60vh] flex items-center justify-center bg-neutral-light">
        <div className="text-center px-4">
          <h1 className="text-5xl md:text-6xl font-bold text-neutral-dark mb-4">404</h1>
          <p className="text-xl md:text-2xl text-neutral-dark/80 mb-8">Oops! Page not found</p>
          <p className="text-lg text-neutral-dark/70 mb-8 max-w-lg mx-auto">
            The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
          </p>
          <Link to="/">
            <Button className="bg-primary text-white hover:bg-primary-dark">
              Return to Home
            </Button>
          </Link>
        </div>
      </div>
    </Layout>
  );
};

export default NotFound;
