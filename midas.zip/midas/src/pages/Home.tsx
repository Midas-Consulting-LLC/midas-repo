
import React from 'react';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import SectionHeading from '@/components/SectionHeading';
import { Check, Target, Users, Database, ArrowRight } from 'lucide-react';
import CallToAction from '@/components/CallToAction';

const Home: React.FC = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-20 md:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold text-neutral-dark mb-6">
                Drive Growth with Expert Outsourced Sales & AI-Powered Leads
              </h1>
              <p className="text-lg md:text-xl text-neutral-dark/80 mb-8">
                Outsource your sales operations to an experienced team, powered by cutting-edge AI for quality lead generation.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/book-consultation">
                  <Button className="bg-primary text-white hover:bg-primary-dark text-lg px-6 py-6 h-auto">
                    Book a Free Consultation
                  </Button>
                </Link>
                <Link to="/services">
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white text-lg px-6 py-6 h-auto">
                    Explore Services
                  </Button>
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <img 
                src="/placeholder.svg" 
                alt="Sales Growth Visualization" 
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Problem-Solution Section */}
      <section className="bg-white">
        <div className="container-custom py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-neutral-dark mb-6">
              Is Your Sales Team Struggling to Scale?
            </h2>
            <p className="text-lg text-neutral-dark/80 mb-6">
              High overhead, poor lead quality, and limited internal resources can stall your growth.
            </p>
            <p className="text-xl text-primary font-semibold">
              We blend 20+ years of enterprise sales experience with AI tools to deliver a steady pipeline of qualified leads.
            </p>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <SectionHeading
            title="Our Core Solutions"
            subtitle="Optimize your sales cycle from initial lead generation to final close with our specialized services."
            centered={true}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Service 1 */}
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="text-primary mb-4">
                <Users size={48} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Outsourced Sales Teams</h3>
              <p className="text-neutral-dark/80 mb-4">
                Tap into seasoned professionals who manage outreach, follow-up, and deal closure.
              </p>
              <Link to="/services#OutsourcedSalesTeams" className="flex items-center font-medium text-primary">
                <span>Learn more</span>
                <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>

            {/* Service 2 */}
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="text-primary mb-4">
                <Target size={48} />
              </div>
              <h3 className="text-xl font-semibold mb-3">AI-Powered Lead Generation</h3>
              <p className="text-neutral-dark/80 mb-4">
                Leverage advanced data tools to pinpoint and prioritize the highest-potential prospects.
              </p>
              <Link to="/services#AIPoweredLeadGen" className="flex items-center font-medium text-primary">
                <span>Learn more</span>
                <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>

            {/* Service 3 */}
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <div className="text-primary mb-4">
                <Database size={48} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Lead Research & Enrichment</h3>
              <p className="text-neutral-dark/80 mb-4">
                Gain deeper insights into your prospects to personalize outreach and increase conversions.
              </p>
              <Link to="/services#LeadResearch" className="flex items-center font-medium text-primary">
                <span>Learn more</span>
                <ArrowRight size={16} className="ml-1" />
              </Link>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link to="/services">
              <Button className="bg-primary text-white hover:bg-primary-dark">
                View All Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section className="bg-white">
        <div className="container-custom py-16 md:py-24">
          <h2 className="text-3xl font-bold text-center text-neutral-dark mb-12">
            Why Trust Us?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Trust Point 1 */}
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Check size={32} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">20+ Years Experience</h3>
              <p className="text-neutral-dark/80">
                Enterprise sales expertise from NCR background
              </p>
            </div>

            {/* Trust Point 2 */}
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Check size={32} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">AI-Driven Approach</h3>
              <p className="text-neutral-dark/80">
                Superior lead accuracy and qualification
              </p>
            </div>

            {/* Trust Point 3 */}
            <div className="text-center">
              <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <Check size={32} className="text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Proven Results</h3>
              <p className="text-neutral-dark/80">
                For SMBs and Fortune 500 Resellers alike
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <SectionHeading
            title="Our 4-Step Process to Boost Your Pipeline"
            centered={true}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Step 1 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold mb-4">
                1
              </div>
              <h3 className="text-lg font-semibold mb-2">Strategy & Setup</h3>
              <p className="text-neutral-dark/80">
                Define goals and create your unique sales approach
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold mb-4">
                2
              </div>
              <h3 className="text-lg font-semibold mb-2">AI Lead Identification</h3>
              <p className="text-neutral-dark/80">
                Use technology to find your ideal prospects
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold mb-4">
                3
              </div>
              <h3 className="text-lg font-semibold mb-2">Human Qualification</h3>
              <p className="text-neutral-dark/80">
                Expert review ensures lead quality
              </p>
            </div>

            {/* Step 4 */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center font-bold mb-4">
                4
              </div>
              <h3 className="text-lg font-semibold mb-2">Sales Engagement</h3>
              <p className="text-neutral-dark/80">
                Expert outreach and handover of qualified opportunities
              </p>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link to="/how-it-works">
              <Button className="bg-primary text-white hover:bg-primary-dark">
                Learn More About Our Process
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CallToAction
        headline="Ready to Scale Your Sales Pipeline?"
        description="Let us handle the heavy lifting. Our data-driven methods and hands-on expertise ensure you meet—and exceed—your revenue goals."
        buttonText="Contact Us Today"
        buttonLink="/contact"
        bgColor="primary"
      />
    </Layout>
  );
};

export default Home;
