
import React from 'react';
import Layout from '@/components/Layout';
import SectionHeading from '@/components/SectionHeading';
import ServiceCard from '@/components/ServiceCard';
import CallToAction from '@/components/CallToAction';
import { Users, Target, Database, Server, BarChart3 } from 'lucide-react';

const Services: React.FC = () => {
  return (
    <Layout>
      {/* Header Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-5xl font-bold text-neutral-dark mb-6">
              Our Outsourced Sales Solutions
            </h1>
            <p className="text-lg md:text-xl text-neutral-dark/80">
              Optimize your sales cycle from initial lead generation to final close. Our solutions adapt to your unique goals and challenges.
            </p>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="bg-white" id="OutsourcedSalesTeams">
        <div className="container-custom py-16 md:py-24">
          <SectionHeading
            title="Our Core Services"
            subtitle="Comprehensive solutions tailored to drive your sales growth."
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            <ServiceCard
              title="Outsourced Sales Teams"
              description="Gain a full-scale sales team without the overhead of hiring, onboarding, and managing in-house staff. Our experts function as an extension of your brand to drive consistent revenue growth."
              benefits={[
                "Scalable, on-demand sales force",
                "Reduced HR and operational costs",
                "Proven methodologies to shorten sales cycles"
              ]}
              icon={<Users size={48} />}
              link="/contact"
              idealFor="SMBs and resellers looking to quickly expand market reach and close more deals."
            />

            <ServiceCard
              title="AI-Powered Lead Generation"
              description="We harness advanced AI tools to filter large datasets, targeting leads most likely to convert based on your ideal customer profile. Our system continuously learns and refines, ensuring a pipeline of high-quality opportunities."
              benefits={[
                "Increased lead accuracy",
                "Improved conversation-to-close ratios",
                "Reduced manual data scrubbing"
              ]}
              icon={<Target size={48} />}
              link="/contact"
              idealFor="Organizations needing a steady influx of qualified leads without the guesswork."
            />

            <ServiceCard
              title="Lead Research & Enrichment"
              description="Our team augments basic lead data with critical insights—company background, decision-makers, pain points—to help you tailor your pitch effectively."
              benefits={[
                "Personalized outreach and messaging",
                "Higher email open and response rates",
                "Shortened discovery process for sales reps"
              ]}
              icon={<Database size={48} />}
              link="/contact"
              idealFor="Sales teams aiming to maximize conversion rates through data-driven personalization."
            />
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="bg-neutral-light">
        <div className="container-custom py-16 md:py-24">
          <SectionHeading
            title="Our Technology Stack"
            subtitle="We bring together best-in-class AI platforms, CRM integrations, and analytics tools to deliver measurable outcomes."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-primary mb-4">
                <Server size={36} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Proprietary AI Algorithms</h3>
              <p className="text-neutral-dark/80">
                Our custom-developed algorithms scrub and analyze prospect data to identify the best-fit leads for your business.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-primary mb-4">
                <Database size={36} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Enterprise CRM Integration</h3>
              <p className="text-neutral-dark/80">
                Seamless connections with popular platforms like Salesforce, HubSpot, and other enterprise CRMs.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-primary mb-4">
                <BarChart3 size={36} />
              </div>
              <h3 className="text-xl font-semibold mb-3">Analytics Dashboards</h3>
              <p className="text-neutral-dark/80">
                Custom reporting tools that provide real-time insights into your sales pipeline and performance metrics.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <CallToAction
        headline="Find the Right Solution for Your Business"
        description="Whether you need a fully outsourced team or simply better leads, we have the service for you."
        buttonText="Book a Consultation"
        buttonLink="/book-consultation"
        bgColor="primary"
      />
    </Layout>
  );
};

export default Services;
